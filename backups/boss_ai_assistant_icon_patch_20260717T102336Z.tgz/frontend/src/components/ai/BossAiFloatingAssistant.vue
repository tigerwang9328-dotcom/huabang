<template>
  <div v-if="canShowAssistant" class="boss-ai-floating" :class="{ minimized, dragging }" :style="panelStyle">
    <button v-if="minimized" type="button" class="floating-launcher" @click="minimized = false">
      <span>老板AI助手</span>
    </button>
    <section v-else class="floating-panel">
      <header class="floating-header" @mousedown="startDrag">
        <strong>老板AI助手</strong>
        <div class="floating-actions">
          <button type="button" title="新建对话" @click.stop="chatRef?.startNewConversation()">新建</button>
          <button type="button" title="历史记录" @click.stop="router.push('/app/ai')">历史</button>
          <button type="button" title="最小化" @click.stop="minimized = true">-</button>
          <button type="button" title="全屏展开" @click.stop="router.push('/app/ai')">↗</button>
        </div>
      </header>
      <BossAiChat ref="chatRef" mode="floating" />
    </section>
  </div>
</template>

<script setup lang="ts">
import { computed, onBeforeUnmount, ref } from "vue";
import { useRouter } from "vue-router";
import { useAuthStore } from "@/stores/auth";
import BossAiChat from "@/components/ai/BossAiChat.vue";

const router = useRouter();
const authStore = useAuthStore();
const minimized = ref(false);
const dragging = ref(false);
const chatRef = ref<InstanceType<typeof BossAiChat>>();
const position = ref({ right: 24, bottom: 24 });
let dragStart = { x: 0, y: 0, right: 24, bottom: 24 };

const canShowAssistant = computed(() =>
  authStore.hasPermission("knowledge:ai:view") &&
  authStore.hasAnyRole("boss", "ceo", "shareholder", "admin", "super_admin", "owner", "administrator", "general_manager")
);

const panelStyle = computed(() => ({
  right: `${position.value.right}px`,
  bottom: `${position.value.bottom}px`,
}));

const startDrag = (event: MouseEvent) => {
  if (window.innerWidth <= 700) return;
  dragging.value = true;
  dragStart = {
    x: event.clientX,
    y: event.clientY,
    right: position.value.right,
    bottom: position.value.bottom,
  };
  window.addEventListener("mousemove", onDrag);
  window.addEventListener("mouseup", stopDrag);
};

const onDrag = (event: MouseEvent) => {
  if (!dragging.value) return;
  const nextRight = dragStart.right - (event.clientX - dragStart.x);
  const nextBottom = dragStart.bottom - (event.clientY - dragStart.y);
  position.value = {
    right: Math.max(12, Math.min(window.innerWidth - 440, nextRight)),
    bottom: Math.max(12, Math.min(window.innerHeight - 320, nextBottom)),
  };
};

const stopDrag = () => {
  dragging.value = false;
  window.removeEventListener("mousemove", onDrag);
  window.removeEventListener("mouseup", stopDrag);
};

onBeforeUnmount(stopDrag);
</script>

<style scoped>
.boss-ai-floating {
  position: fixed;
  z-index: 1100;
}
.floating-launcher {
  width: 148px;
  height: 44px;
  border: 0;
  border-radius: 8px;
  color: #ffffff;
  background: #0f766e;
  box-shadow: 0 10px 26px rgba(15, 23, 42, 0.18);
  cursor: pointer;
  font-weight: 700;
}
.floating-panel {
  display: flex;
  flex-direction: column;
  width: 420px;
  height: min(560px, calc(100vh - 48px));
  overflow: hidden;
  border: 1px solid #cbd5e1;
  border-radius: 8px;
  background: #ffffff;
  box-shadow: 0 18px 42px rgba(15, 23, 42, 0.22);
}
.floating-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 8px;
  padding: 10px 12px;
  color: #ffffff;
  background: #0f766e;
  cursor: move;
}
.floating-actions {
  display: flex;
  gap: 6px;
}
.floating-actions button {
  display: grid;
  min-width: 28px;
  height: 28px;
  place-items: center;
  padding: 0 6px;
  border: 1px solid rgba(255, 255, 255, 0.5);
  border-radius: 8px;
  color: #ffffff;
  background: transparent;
  cursor: pointer;
}
.dragging {
  user-select: none;
}
@media (max-width: 700px) {
  .boss-ai-floating {
    inset: 0 !important;
  }
  .floating-panel {
    width: 100vw;
    height: 100vh;
    border: 0;
    border-radius: 0;
  }
  .floating-header {
    cursor: default;
  }
}
</style>
